export const audioTracks=[
    {
        file:"audio1",
        title: "Jolene (cover)",
        artist:"Mădălina Candrea-Băbuț",
        description:["înregistrare/procesare voce","mix","master"],

    },
    {
        file:"audio2",
        title: "O batrană într-o gară",
        artist:"Acord Band Vatra Dornei",
        description:["înregistrare/procesare instrumente","înregistrare/procesare voce","mix","master"],

    },
    {
        file:"audio3",
        title: "Almost is Never Enough (cover)",
        artist:"Camelia Lucescu",
        description:["înregistrare/procesare voce","mix","master"],

    },
    {
        file:"audio4",
        title: "Din cer coboară sfânt colind",
        artist:"Cristina Doroftiesei",
        description:["înregistrare/procesare instrumente","înregistrare/procesare voce","mix","master"],

    },
    {
        file:"audio5",
        title: "Hip-Hop & Autentic Fusion",
        artist:"Marius Ciprian",
        description:["producție instrumental","înregistrare/procesare instrumente","mix","master"],

    },
    {
        file:"audio6",
        title: "Saxofonul care plânge",
        artist:"Marius Ciprian",
        description:["înregistrare/procesare instrumente","mix","master"],

    },
    {
        file:"audio7",
        title: "Filmul meu",
        artist:"Pintea",
        description:["înregistrare/procesare voce","mix","master"],

    },
    
]