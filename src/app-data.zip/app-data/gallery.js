export const pictures=[
    {
        name:"gallery1",
        orientation: "landscape",
        category:"peisaj"
    },
    {
        name:"gallery2",
        orientation: "portrait",
        category:"portret"
    },
    {
        name:"gallery3",
        orientation: "square",
        category:"produs"
    },
    {
        name:"gallery4",
        orientation: "portrait",
        category:"produs"
    },
    {
        name:"gallery5",
        orientation: "square",
        category:"produs"
    },
    {
        name:"gallery6",
        orientation: "landscape",
        category:"portret"
    },
    {
        name:"gallery7",
        orientation: "portrait",
        category:"produs"
    },
    {
        name:"gallery8",
        orientation: "landscape",
        category:"portret"
    },
    {
        name:"gallery9",
        orientation: "portrait",
        category:"peisaj"
    },
    {
        name:"gallery10",
        orientation: "square",
        category:"peisaj"
    },
    {
        name:"gallery11",
        orientation: "portrait",
        category:"peisaj"
    },
    {
        name:"gallery12",
        orientation: "square",
        category:"peisaj"
    },
    {
        name:"gallery13",
        orientation: "landscape",
        category:"peisaj"
    },
    {
        name:"gallery14",
        orientation: "portrait",
        category:"portret"
    },
    {
        name:"gallery15",
        orientation: "landscape",
        category:"produs"
    },
    {
        name:"gallery16",
        orientation: "portrait",
        category:"produs"
    },
    {
        name:"gallery17",
        orientation: "square",
        category:"portret"
    },
    {
        name:"gallery18",
        orientation: "portrait",
        category:"portret"
    },
    {
        name:"gallery19",
        orientation: "square",
        category:"portret"
    },
    {
        name:"gallery20",
        orientation: "landscape",
        category:"produs"
    },
    {
        name:"gallery21",
        orientation: "portrait",
        category:"peisaj"
    },
]