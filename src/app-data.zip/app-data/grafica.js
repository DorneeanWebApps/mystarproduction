export const graficItems=[
    {
        buton:"graficbuton1",
        imagine: "grafica1",
        buttonTitle: "Afise",
        title: "Afise Club",
    },
    {
        buton:"graficbuton2",
        imagine: "grafica2",
        buttonTitle: "Afise",
        title: "Afise Evenimente",
    },
    {
        buton:"graficbuton3",
        imagine: "grafica3",
        buttonTitle: "puzzle",
        title: "Instagram Puzzle",
    },
     {
        buton:"graficbuton4",
        imagine: "grafica4",
        buttonTitle: "Cover",
        title: "Cover facebook / youtube",
    },
    {
        buton:"graficbuton5",
        imagine: "grafica5",
        buttonTitle: "story",
        title: "Story Instagram & Facebook",
        video: "story",
        mobileVideo: "story1",
        width: 1098,
        height: 404
    },
    {
        buton:"graficbuton6",
        imagine: "grafica6",
        title: "Promo video",
        buttonTitle: "promo",
        link: "t7NIImBxmg0"
    },
    {
        buton:"graficbuton7",
        imagine: "grafica7",
        title: "Video din afis",
        buttonTitle: "video",
        link: "qxlHHAs4aFc",
    }, 
    {
        buton:"graficbuton8",
        imagine: "grafica8",
        buttonTitle: "Logo",
        title: "Logo",
    },
    {
        buton:"graficbuton9",
        imagine: "grafica9",
        buttonTitle: "Pliant",
        title: "Pliant",
    }, 
    {
        buton:"graficbuton10",
        imagine: "grafica10",
        buttonTitle: "Flyere",
        title: "Flyere",
    }, 
    
]