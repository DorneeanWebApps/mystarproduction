export const testimonialItems=[
    {
        foto:"adi",
        name: "Adrian CHIFORESCU",
        titlu: "CEO Hotel-Restaurant DORNA",
        text: "Mereu disponibil, foarte receptiv la solicitările mele, Michael e unul dintre  profesioniștii pe care ti l-ai dori multiplicat in toți furnizorii cu care colaborezi! Operativ și empatic ne-a livrat mereu materialele in termenul agreat la începutul campaniilor!",
    },  
    {
        foto:"andi",
        name: "Andi VEZETEU",
        titlu: "Manager Complex Turistic Bradul-Calimani",
        text: "Colaborarea cu MySTAR Production a fost o alegere foarte inspirata. Sunt foarte incantat de cum au decurs lucrurile. Materialele au fost livrate inainte de termenul stabilit si rezultatul a fost pe masura asteptarilor noastre. Michael e foarte cooperant si deschis la idei noi. Evident, vom continua colaborarea.",
    },  
    {
        foto:"ripan",
        name: "Marius RIPAN",
        titlu: "Viceprimar VATRA DORNEI",
        text: "Bla bla bal",
    },  
    {
        foto:"doru",
        name: "Doru BIGHIU",
        titlu: "Director ORION MEDIA",
        text: "Bla bla bal",
    },  
    {
        foto:"laura",
        name: "Laura ERHAN",
        titlu: "Artist",
        text: "Energie, vibe bun și profesionalism... Când faci cunoștința cu el, cu Michael, dai de o persoana serioasa, sobră as putea spune, după câteva vorbe schimbate cu el, îți dai seama ca este cel mai cool om din lume. De fiecare data când ne intalnim la evenimente, aduce cu el cea mai tare stare de spirit, ca un profesionist, lasă acasa toate problemele personale și este dedicat, având ca scop un eveniment de succes. Când am pășit prima oara in studioul lui m-am simțit ca acasa. M-a primit cu brațele deschise, mi-a împărtășit proiectele lui cu mare caldura, ca unui prieten apropiat. Mi-a câștigat rapid încrederea și am știut ca are cel mai profi echipament, in așa fel încât rezultatele sa fie pe măsura așteptărilor. Michael, sper sa ai doar feedback-uri bune, pentru ca le MERITI!",
    },   
    {
        foto:"madalina",
        name: "Madalina CANDREA BABUT",
        titlu: "Artist",
        text: "Studio impecabil, totul fiind profi și foarte bine organizat; dar să vorbim despre OMUL care face ca totul sa fie asa cum am spus. Am lucrat in cateva studiouri cu diferiți oameni însă experiența din acest studio alături de Michael a fost de departe cea mai plăcută! Un om cu un caracter de nota 100 care stie sa încurajeze si sa te faca sa te simti in largul tau chiar și atunci când mai greșești. Despre calitatea muncii si implicarea lui am spus si mai sus, așadar, recomand cu tot dragul si abia astept sa lucram din nou, la cat mai multe proiecte!",
    },    
    {
        foto:"vasile",
        name: "Vasile MOROSAN",
        titlu: "Director Ansamblul Folcloric Plaiurile Dornelor",
        text: "Studio profi, cu tot ce trebuie, totul nou. Michael, ca de fiecare data, foarte implicat și dedicat total pentru ceea ce face!",
    },    
    {
        foto:"marius",
        name: "Marius TARAN",
        titlu: 'Student al Universitatii Nationale de Arte "George Enescu" Iasi',
        text: "Cel mai tare loc de inregistrat!!! Recomand cu toata incredereeea, totul este profesionaaal. Eu aici inregistrez si filmez aboslut totul si sunt supeeer multumit!!! Daca doriti ceva de calitate aici este locul potrivit!!!",
    },    
]